import UIKit

// Code snippet 1
class CrossWalk {
  var roadName: String
  var address: String
    
  init(_ roadName: String, at address: String) {
    self.roadName = roadName
    self.address = address
  }

  func info() {
    print("\(roadName) @ \(address)")
  }
}

var cw = CrossWalk("Titan Hall", at: "1111 N State College Blvd, Fullerton, CA 92831")
cw.info()

/* Screen output: Titan Hall @ 1111 N State College Blvd, Fullerton, CA 92831 */


// Code snippet 2

// The IntersectionCrossWalk inherits from CrossWalk
class IntersectionCrossWalk : CrossWalk {
  var intersection: String
  
  init(_ roadName: String, at address: String,
       and intersection: String) {
    /* Initialize subclass properties before calling the base class'
       initializer. */
    self.intersection = intersection
    super.init(roadName, at: address)
  }

  func intersectionTuple() -> (String, String) {
    return (address, intersection)
  }
    
  override func info() {
    super.info()
    print(" and \(intersection).")
  }
}

var icw = IntersectionCrossWalk("Yorba Linda Crosswalk",
             at: "1111 N State College Blvd, Fullerton, CA 92831",
             and: "Yorba Linda Ave.")

icw.info()
/* Screen output: Yorba Linda Crosswalk @ 1111 N State College Blvd,
   Fullerton, CA 92831 and Yorba Linda Ave. */

var (address, intersection) = icw.intersectionTuple()
print(address)

// Screen output: 1111 N State College Blvd, Fullerton, CA 92831

// Code snippet 3

protocol Announceable {
  var name: String { get set }
  var speakerLabel: String { get }

  func announce(message: String)
}

/* Classes that implement a protocol must provide all properties and
   methods declared in the protocol */
class Update : Announceable {
    // Implementation of required properties
    var name: String
    var speakerLabel: String {
        return "[\(name)]"
    }
    
    init(name: String) {
      self.name = name
    }
    
    // Implementation of required method
    func announce(message: String) {
        print("\(speakerLabel) \(message)")
    }
}

var road = Update(name: "Road update")
road.announce(message: "There is construction at Yorba Linda Ave.")
/* Screen output: [Road update] There is construction
                at Yorba Linda Ave. */




road.name = "Public Service Announcement"
print("New name: \(road.name)")
road.announce(message: "There is construction at Yorba Linda Ave.")
/* Screen output: New name: Public Service Announcement
                  [Public Service Announcement] There is construction
                  at Yorba Linda Ave. */

print("Speaker label: \(road.speakerLabel)")
// Screen output: Speaker label: [Public Service Announcement]

/* The code below produces the error:
   cannot assign to property: 'speakerLabel' is a get-only property*/
//road.speakerLabel = "{}"

class tacoTruck: Announceable {
  var name: String
    var speakerLabel: String{
        return "[\(name)]"
    }
    init(name: String) {
      self.name = name
    }
    func announce(message: String){
        print("\(speakerLabel) \(message)" + "​​🌮😋🔥")
    }
}

// Code snippet 4
// extension applies to any existing class
extension String {
    func emojify(with emoji: String) -> String {
        // self returns the String's value
        return "\(emoji) \(self) \(emoji)"
    }
}

var greeting = "Hello"
print(greeting.emojify(with: "👋"))
print("Tacccooooooos".emojify(with: "🌮"))

extension Int {
    func cube(using number: Int) -> Int {
        return \self^3
    }

    func decorate(with emoji: String) -> String {
        return "\(emoji) \(self) \(emoji)"
    }

    func last(of number: Int) -> Int {
        return number % 10
    }
}

