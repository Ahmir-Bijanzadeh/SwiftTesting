import UIKit

//var greeting = "Hello, playground"
// Code snippet 1

// uninitialized String variable
//var name: String

// initialized String variable with data type
//var city: String = "Fullerton"

/* initialized String variable without data type
 The compiler sets state's type to String because "CA" is a string */
//var state = "CA"

// Swift does not require the main() method. The compiler runs code that is not inside a structure, class, or function.
// Code snippet 2
/* You can end statements with semicolons (;) in Swift, but they are
   are not required. Most code used in this class does not use
   semicolons but you are free to choose your own style. Just make
   sure it is consistent (i.e., always use semicolons, or no
   semicolons)
*/

// initialized String
var city = "Fullerton";

// replace city's value
city = "Pittsburgh";

// initialized String constant
let state = "CA";

// Syntax error: You cannot modify the value of a constant
//state = "PA";

//print is a function that displays Strings on the console.

var name = "Tuffy Titan"

print("Hello I am \(name) from \(city), \(state)")

//print is a function that displays Strings on the console.

print("Hello I am \(name) from \(city), \(state)")
