import UIKit

/* Code snippet 1*/

/* Tuples are data types that store two or more values that may be
   of different types */
var accessory = (5, "safety vest", 10.00)

/* We can access elements of a tuple using a dot notation and a
   zero-based index */
print("(Index-based) Count: \(accessory.0)")
print("(Index-based) Type: \(accessory.1)")
print("(Index-based) Cost: \(accessory.2)")

/* Alternatively, we can store each value of a tuple in a separate
   variable. In this example, this is equivalent to assigning
   accessory.0 to the variable count, accessory.1 to name, and
   accessory.2 to cost */
var (count, name, cost) = accessory
print("(Variables) Count: \(count)")
print("(Variables) Type: \(name)")
print("(Variables) Cost: \(cost)")

/* If you don't need all values from the tuple, you can provide a
   variable name for values you need and an _ for everything else. */
var (_, _, theCost) = accessory
print("(Omitted variables) Cost: \(theCost)")

/* You can provide labels to tuple values so you can access them
   using the labels or the index */
var log = (type: "attendance", time: 1300 , value: true)
print("(Index-based) Type: \(log.0)")
print("(Label-based) Type: \(log.type)")
print("(Label-based) Time: \(log.time)")
print("(Label-based) Value: \(log.value)")

(Index-based) Count: 5
(Index-based) Type: safety vest
(Index-based) Cost: 10.0
(Variables) Count: 5
(Variables) Type: safety vest
(Variables) Cost: 10.0
(Omitted variables) Cost: 10.0
(Index-based) Type: attendance
(Label-based) Type: attendance
(Label-based) Time: 1300
(Label-based) Value: true

// Code snippet 2

/* Adding a ? after a data type makes the variable an optional.
   Optionals are variables that can store a value of the specified
   data type or nil (null). If we do not initialize the optional's
   value it is set to nil by default. */
var age: Int?

/* This statement produces the error: Value of optional type 'Int?'
   must be unwrapped to a value of type 'Int' */

print("Age next year: \(age + 1)")

/* Swift ensures nil safety by forcing developers to "unwrap" the
   value of an optional regardless if it has a nil value or not. One
   way to unwrap the value is to use the if-let syntax shown below. */

/* If age is not nil, it can be assigned to validAge, a non-optional
   variable with the same base data type as the optional (in this
   case Int). You can use the variable safely inside the first code
   block. */
if let validAge = age {
    print("Age next year: \(validAge + 1)")
} else {
    /* If age is nil, it cannot be assigned to validAge because
       validAge is not an optional (can't store nil values). In such
       a case code in the else block is executed instead. */
    print("No age provided.")
}

/* Alternatively you can force unwrap an optional, but it can be
   dangerous so the if-let syntax is the suggested method. */
print("Age next year: \(age! + 1)")

age = 25

/* The age next year should now be printable because age has a
   non-nil value, 25. */

if let validAge = age {
    print("Age next year: \(validAge + 1)")
} else {
    print("No age provided.")
}

var birthday: String?

/* You can unwrap multiple optionals in a single if-let statement by
   separating them with a comma (,) and use the corresponding
   variables in the code blocks. */
if let validAge = age, let validBirthday = birthday {
    print("You will be \(validAge + 1) on \(validBirthday)")
} else {
    /* In this case Incomplete information is printed because
       birthday is nil. */
    print("Incomplete information.")
}

let temperature = 100
if temperature >= 100 {
  print("The water is boiling.")
} else {
  print("The water is not boiling.")
}

let finishPosition = 2
 
if finishPosition == 1 {
  print("Congratulations, you won the gold" +
        "medal!")
} 
else if finishPosition == 2 {
    print("You came in second place, you " + "won a silver medal")
}
else {
  print("You did not win a gold or silver " + "medal")
}

        let character = "z"
         
        switch character {
        case "a", "e", "i", "o", "u":
            print("This character is a vowel.")
        default:
            print("This character is a consonant.")
        }

let distance = 36
switch distance {
case 0...9:
/* accept all values between 0 and 9
   (inclusive) */
    print("You're close.")
/* Take note that cases don't fall through so
   there is no break statement. */
case 10...99:
    print("You're kinda close.")
case 100...999:
    print("You're far.")
default:
    print("Are you sure you want to go?")
}

