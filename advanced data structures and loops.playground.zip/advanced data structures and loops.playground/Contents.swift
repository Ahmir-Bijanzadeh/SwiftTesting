import UIKit

//var greeting = "Hello, playground"
// Code snippet 1
/* The syntax for creating and using structures and classes are identical except it uses the struct keyword. However, structs cannot be used to implement inheritance. Their behavior can also be different as shown below. */

struct VolunteerStruct {
    var name: String
    var age: Int
    
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
    
    func info() {
        print("\(name) (\(age))")
    }
}

// Initializing objects from structures
var erin = VolunteerStruct(name: "Erin Jackson", age: 29)
var erinToo = erin
erin.info()    // Outputs: Erin Jackson (29)
erinToo.info() // Outputs: Erin Jackson (29)

print("Changing Erin's age ...")
erinToo.age = 30
erin.info()    // Outputs: Erin Jackson (29)
erinToo.info() // Outputs: Erin Jackson (30)




// Code snippet 2
/* Pay attention to the screen display difference between classes and
   structures. */

class VolunteerClass {
    var name: String
    var age: Int
    
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
    
    func info() {
        print("\(name) (\(age))")
    }
}

var chloe = VolunteerClass(name: "Chloe Kim", age: 21)
var chloeToo = chloe
chloe.info()    // Outputs: Chloe Kim (21)
chloeToo.info() // Outputs: Chloe Kim (21)

print("Changing Chloe's age ...")
chloeToo.age = 22
chloe.info()    // Outputs: Chloe Kim (22)
chloeToo.info() // Outputs: Chloe Kim (22)

// Code snippet 3

/* Enumerations provide a defined set of values. */
enum Role {
  case admin
  case moderator
  case user
}

struct User {
  var username: String
  var role: Role // property with an enumeration type

  init(username: String, role: Role) {
    self.username = username
    self.role = role
  }
}
// Two ways to assign enumeration values
var me = User(username: "pinventado", role: Role.admin)
var you = User(username: "ttitan", role: .user)


var pedestrians
    = [15, 20, 18, 25, 20]

for count in pedestrians {
    print("Count: \(count)")
}

for i in 0...pedestrians.count - 1 {
  print("Count: \(pedestrians[i])")
}
var volunteers = [
    "Tuffy": 64,
    "Erin": 29,
    "Chloe": 21
]

for (name, age) in volunteers {
    print("\(name): \(age)")
}

// Take note that the order of elements visited may not be in the same order as when the dictionary was created.
