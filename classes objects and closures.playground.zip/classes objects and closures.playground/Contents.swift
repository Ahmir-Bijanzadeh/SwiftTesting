import UIKit

var greeting = "Hello, playground"
// Code snippet 1

// Name of the class
class Person {
    // Properties
    var name: String
    var age: Int?

    // Initializer (constructor)
    init(name: String, age: Int?) {
        /* self distinguishes properties from parameters with the
           same name. In this case, name and age. */
        self.name = name
        self.age = age
    }
    
    // Overloaded initializer
    init(name: String) {
        self.name = name
        self.age = nil
    }
    
    /* Deinitializer (destructor) called when the object is removed
       from memory. */
    deinit {
        print("\(name) is exiting the building...")
    }
    
    // Methods
    func sayHello() {
        /* We don't need to use self because the compiler can figure
           out that we mean the name and age properties. */
        print("Hello, there! My name is \(name).")
        // We need to unwrap an optional Int
        if let myAge = age {
            print("I am \(myAge) this year.")
        }
    }
}
/* Create a Person instance (object) by using the class name and providing values for its parameters. */
var me = Person(name: "Tuffy Titan", age: 64)
// Modify properties using the dot notation
me.age = 65
// Call member functions using the dot notation
me.sayHello()

var you = Person(name: "Paul")
you.sayHello()

// Code snippet 2


class StreetIntersection {
    // Properties
    var length: Double
    var width: Double
    
    /* We can use computed properties to store and retrieve values
       based on other properties. We use an enclosing { } after a
       property declaration to define the computed property. */
    var area: Double {
        /* get blocks are like functions that don't have parameters
           and return the same type as the computed property; in this
           case, Double. They are called when we retrieve the value
           of the computed property. */
        get {
            return length * width
        }
        /* set blocks are like functions that only require the
           parameter name whose data type is the same as the computed
           property; in this case, Double. They are called when we
           assign a value to the computed property. The value is
           accessible using the parameter name; in this case newArea.
        */
        set(newArea) {
            /* In this implementation, we assume the intersection
               forms a square so we get the square root and assign
               the same value to length and width. */
            width = newArea.squareRoot()
            length = width
        }
    }
    
    init(length: Double, width: Double) {
        self.length = length
        self.width = width
    }
}


var intersection = StreetIntersection(length: 10.5, width: 15.3)


// Accessing the computed property calls the get block
print(intersection.area) // 160.65


/* Assigning a value to the computed property calls the set block and passes the value; in this case 35.0 */
intersection.area = 35.0


// The length and width properties are updated by area's set block.
print(intersection.length) // 5.916
print(intersection.width)  // 5.916


/* You can create a computed property with a get block only, which we call a get-only property. However, take note that you will get an error if you try assigning it a value. You can omit the get keyword for get-only computed properties. Here is a modified version of the area computed property that only returns a value:


var area: Double {
  return length * width
}
*/
// Code snippet 3


class Account {
    var username: String
    var password: String
    
    init(username: String, password: String) {
        self.username = username
        self.password = password
    }
    
    /* We create a method that accepts a function type parameter.
       Specifically, it accepts a single String parameter and returns
       a String. */
    func info(censor: (String) -> String) {
        print("username: \(username)")
        /* We call the passed function to censor the password
           property. */
        let censoredPassword = censor(password)
        print("password: \(censoredPassword)")
    }
}


var myAccount = Account(username: "pinventado", password: "s3cr3t")


/* Take note that censorSymbol is declared here and is not accessible from inside myAccount. */
var censorSymbol = "*"
var websiteURL = "https://supersecureaccounts.com"




















// We call the info function and pass a closure expression
myAccount.info(censor: {
    (password) -> String in
    /* We create a String that repeats the censorSymbol depending on
       the number of characters in the password. For example, if you
       have a 4-letter password and an * censorSymbol then it
       produces the string "****".
     
        Closures get its name from the closure expression's ability
        to access all variables in the scope where it was called.


        Closures are often used when you need access to information
        or components in your closure expression that are not
        available to the calling function or method. */
        var display = ""
        for _ in 1...password.count {
            display += censorSymbol
        }
        // Can also use a String initializer
        // String(repeating: censorSymbol, count: password.count)
        return display
})
