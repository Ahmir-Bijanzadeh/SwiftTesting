import UIKit

//var greeting = "Hello, playground"
// Code snippet 1

struct DollarStore {
  var inventory: [String: Int]

  init(inventory: [String: Int]) {
    self.inventory = inventory
  }

  /* Structures require the mutating keyword if it changes its
     properties */
  mutating func purchase(_ quantity: Int, _ item: String) -> Double {
    if let available = inventory[item] {
      if available >= quantity {
        inventory[item] = available - quantity
        return quantity
      } else {
        return 0.0
      }
    } else {
        return 0.0
    }
  }
}

var sixTen = DollarStore(inventory: [
  "milk" : 10,
  "egg" : 8,
  "tomato" : 7
])

print(sixTen.purchase(3, "egg"))   // Outputs: 3.0
print(sixTen.purchase(11, "milk")) // Outputs: 0.0
print(sixTen.purchase(5, "soda"))  // Outputs: 0.0

// Code snippet 2: Exception handling in Swift

// Component 1: Error enumeration
enum PurchaseError: Error {
    case NotInInventory
    case NotEnoughStock
}

struct DollarStore {
    var inventory: [String: Int]

    init(inventory: [String: Int]) {
      self.inventory = inventory
    }
    
    // Component 2: Exception throwing function
    mutating func purchase(_ quantity: Int, _ item: String)
        throws -> Double {
        if let available = inventory[item] {
            if available >= quantity {
                inventory[item] = available - quantity
                return Double(quantity)
            } else {
                throw PurchaseError.NotEnoughStock
            }
        } else {
            throw PurchaseError.NotInInventory
        }
    }
}

var sixTen = DollarStore(inventory: [
    "milk" : 10,
    "egg" : 8,
    "tomato" : 7
])


// Component 3: Exception Handler - do-try-catch blocks

// Handle specific errors
let item = "soda"
do {
    let sodaPrice = try sixTen.purchase(5, item)
    print("\(item) cost \(sodaPrice)")
} catch PurchaseError.NotInInventory {
    print("\(item) is not in the inventory")
} catch PurchaseError.NotEnoughStock {
    print("Not enough \(item)")
}

// Output:
// soda is not in the inventory

// Component 3: Exception Handler (alternative) - general handler
if let price = try? sixTen.purchase(1, "onion") {
    print("Onion price \(price)")
} else {
    print("Can't purchase onion")
}

// Output: Can't purchase onion

import XCTest // import the XCTest framework
@testable import DollarStore // Name of XCode project

// Extend the XCTestCase class
class DollarStoreTests: XCTestCase {

    // Test cases are functions with names beginning with "test"
    func testValidPurchase() {
        var store = DollarStore(inventory: ["milk": 5])
        /* Checks if both arguments are equivalent. We use the
           keyword try because purchase can throw exceptions. */
        XCTAssertEqual(try store.purchase(2, "milk"), 2.0)
    }
    
    func testValidPurchaseBuyEverything() {
        var store = DollarStore(inventory: ["soda": 8])
        XCTAssertEqual(try store.purchase(8, "soda"), 8.0)
    }
    
    func testThrowNotEnoughStockException() {
        var store = DollarStore(inventory: ["tomato": 3])
        // Checks if the called function throws an error
        XCTAssertThrowsError(try store.purchase(5, "tomato"))
    }
}

/* Apple's XCTest reference website provides a complete list of
   assertions you can use to test your code. */
